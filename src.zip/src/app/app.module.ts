import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { STUDENTComponent } from './student/student.component';
import { LikeComponent } from './like/like.component';
import { CustomPipeComponent } from './pipe/custom-pipe/custom-pipe.component';
import { CustomPipe } from './custom.pipe';

@NgModule({
  declarations: [
    AppComponent,
    STUDENTComponent,
    LikeComponent,
    CustomPipeComponent,
    CustomPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
